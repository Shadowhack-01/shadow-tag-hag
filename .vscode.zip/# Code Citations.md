# Code Citations

## License: unknown
https://github.com/freyhill/freyhill.github.io/tree/93ff85076768e97a60b21dd49bebd8a681a5a912/example/currying/index.html

```
.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"
```


## License: unknown
https://github.com/BB-33/membership-form/tree/f458a00bac3fc95aa6764cf67a0cc6440263725c/index.html

```
option value="female">Female</option>
                <option value="non-binary">Non-binary</option>
                <option value="prefer-not-to-say">Prefer not to say</option>
            </select>
```


## License: Unlicense
https://github.com/mrjoey94/survey-form/tree/d3d594f7eab9655a6df8dc1d8bd84e5c8b201464/index.html

```
" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="non-binary">Non
```


## License: unknown
https://github.com/mathildaduku/simple-html-page/tree/685afba527b594d2531b2f7aa6b1c56fbea2b253/register.html

```
="male">Male</option>
                <option value="female">Female</option>
                <option value="non-binary">Non-binary</option>
                <option value="prefer-not-to-say">Prefer
```


## License: unknown
https://github.com/timrooke1991/getatrainingplan/tree/9cc40daecf36ea2aac7f0cd6af000d01a66ca62e/plans/templates/plans/index.html

```
option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="non-binary">Non-binary</option>
                <option value="prefer-not-to
```

